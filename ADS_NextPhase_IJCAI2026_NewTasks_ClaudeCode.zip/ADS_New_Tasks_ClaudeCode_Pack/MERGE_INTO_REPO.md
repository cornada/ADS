# Merge instructions (Claude Code) — new tasks pack

**Generated:** 2026-01-15

This archive contains **ONLY new tasks/docs** to be merged into your existing repo
(created from `ADS_Start_Zero_ClaudeCode_Full_WindowsSafe.zip`).

## How to apply (Windows-safe)
1) Unzip this archive somewhere (e.g., `C:\work\ads_new_tasks_pack\`).
2) Copy the contents into your existing repo root (the one you already work in):
   - copy `docs/issues/17_*.md` ... `docs/issues/22_*.md`
   - copy `docs/onboarding/NEXT_PHASE_START_HERE.md`
   - copy `docs/checklists/*`
   - copy `docs/paper/*`
   - copy `docs/related_work/*`

3) Commit in a dedicated PR:
   - branch name: `chore/add-next-phase-issues`
   - commit message: `Add IJCAI next-phase task pack (KT10–KT15)`

## After merge
Follow the step-by-step plan:
- `docs/onboarding/NEXT_PHASE_START_HERE.md`



## Tip
After merging this pack, see `docs/onboarding/MEGA_PROMPT_CLAUDE_CODE.md` for a copy/paste mega prompt to automate the first 3 PRs (pack merge + KT10 + KT11).
